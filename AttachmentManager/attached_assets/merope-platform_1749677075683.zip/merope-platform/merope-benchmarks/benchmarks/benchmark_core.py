import time
from merope_core.src.quantum.optimizer import placeholder as optimizer

start = time.perf_counter()
optimizer()
end = time.perf_counter()
print("Optimization runtime:", end - start)