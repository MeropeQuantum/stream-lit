export default function App() {
  return <h1>Merope Quantum Dashboard</h1>;
}