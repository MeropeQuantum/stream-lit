# Placeholder for authentication middleware
def verify_token(token: str) -> bool:
    return True