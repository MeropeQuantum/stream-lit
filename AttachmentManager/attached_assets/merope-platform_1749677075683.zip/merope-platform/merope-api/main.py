from fastapi import FastAPI
from handlers.health import router as health_router

app = FastAPI(title="Merope Quantum API")

app.include_router(health_router, prefix="/health")