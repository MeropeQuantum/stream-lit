import requests

class MeropeClient:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip('/')

    def ping(self):
        return requests.get(f"{self.base_url}/health").json()